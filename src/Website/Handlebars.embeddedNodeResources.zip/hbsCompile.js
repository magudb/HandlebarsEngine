﻿var hbs = require('handlebars');

module.exports = function (callback, viewPath, model, viewDictionary, modelState) {
    // Invoke some external transpiler (e.g., an NPM module) then:
    //var template = hbs.compile(viewPath);
    //model = model || {};
    //model.ViewData = viewDictionary;
    //model.ModelState = modelState;
    //callback(null, template(model));}}
    callback(null, "<h1>funk</h1>");
};